package com.example.walkietalkiepro

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.AudioTrack
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.AudioFocusRequest
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private val serviceUuid: UUID = UUID.fromString("8e6f4a10-7a5b-4c3d-9a10-77d7b7f1a001")
    private var mode = "bluetooth"
    private var socket: android.bluetooth.BluetoothSocket? = null
    private var recording = false
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private lateinit var status: TextView
    private lateinit var talkButton: Button
    private lateinit var deviceList: Spinner
    private var devices: List<android.bluetooth.BluetoothDevice> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestNeededPermissions()
        refreshBluetoothDevices()
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFF09152D.toInt())
        }
        val title = TextView(this).apply {
            text = "اللاسلكي الذكي"
            textSize = 27f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "اتصال صوتي مباشر • اضغط للتحدث"
            textSize = 14f; setTextColor(0xFFB8C8E8.toInt()); gravity = Gravity.CENTER
        }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val bt = Button(this).apply { text = "بلوتوث" }
        val net = Button(this).apply { text = "شبكة / إنترنت" }
        bt.setOnClickListener { mode = "bluetooth"; status.text = "وضع البلوتوث: اختر جهازاً مقترناً ثم اتصل" }
        net.setOnClickListener { mode = "internet"; status.text = "وضع الشبكة: يحتاج إعداد خادم إشارات للاتصال بين الأجهزة." }
        tabs.addView(bt, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(net, LinearLayout.LayoutParams(0, -2, 1f))
        status = TextView(this).apply {
            text = "جاهز • اختر طريقة الاتصال"
            textSize = 15f; setTextColor(0xFF66E2D1.toInt()); gravity = Gravity.CENTER
            setPadding(0, 24, 0, 16)
        }
        deviceList = Spinner(this)
        val refresh = Button(this).apply { text = "تحديث الأجهزة القريبة" ; setOnClickListener { refreshBluetoothDevices() } }
        val connect = Button(this).apply { text = "اتصال بالبلوتوث"; setOnClickListener { connectBluetooth() } }
        talkButton = Button(this).apply {
            text = "اضغط باستمرار للتحدث"
            textSize = 18f
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF1457D9.toInt())
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_DOWN) { startTalking(); true }
                else if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) { stopTalking(); true }
                else true
            }
        }
        val hint = TextView(this).apply {
            text = "ملاحظة: اتصال البلوتوث الحالي يعتمد على اقتران الجهازين أولاً. وضع الإنترنت واجهته جاهزة، ويلزم ربطه بخادم WebRTC لإجراء المكالمات عبر المسافات البعيدة."
            textSize = 12f; setTextColor(0xFFB8C8E8.toInt()); gravity = Gravity.CENTER
            setPadding(8, 22, 8, 0)
        }
        layout.addView(title); layout.addView(subtitle)
        layout.addView(tabs)
        layout.addView(status)
        layout.addView(deviceList)
        layout.addView(refresh)
        layout.addView(connect)
        layout.addView(talkButton, LinearLayout.LayoutParams(-1, 150).apply { topMargin = 26 })
        layout.addView(hint)
        setContentView(layout)
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) {
            needed += Manifest.permission.BLUETOOTH_CONNECT
            needed += Manifest.permission.BLUETOOTH_SCAN
        }
        val missing = needed.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 40)
    }

    @Suppress("MissingPermission")
    private fun refreshBluetoothDevices() {
        try {
            val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter = manager.adapter
            if (adapter == null || !adapter.isEnabled) {
                status.text = "فعّل البلوتوث أولاً"; return
            }
            devices = adapter.bondedDevices.toList()
            val names = if (devices.isEmpty()) listOf("لا توجد أجهزة مقترنة — اقترن من إعدادات الهاتف") else devices.map { it.name ?: it.address }
            deviceList.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
            status.text = "الأجهزة المقترنة: ${devices.size}"
        } catch (e: SecurityException) { status.text = "يرجى السماح بصلاحية البلوتوث" }
    }

    @Suppress("MissingPermission")
    private fun connectBluetooth() {
        if (mode != "bluetooth") { status.text = "اختر وضع البلوتوث أولاً"; return }
        if (devices.isEmpty()) { refreshBluetoothDevices(); status.text = "اقرن الهاتفين من إعدادات البلوتوث أولاً"; return }
        val device = devices.getOrNull(deviceList.selectedItemPosition) ?: return
        status.text = "جارٍ الاتصال بـ ${device.name ?: device.address}..."
        thread {
            try {
                val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                adapter.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(serviceUuid)
                s.connect()
                socket = s
                runOnUiThread { status.text = "متصل عبر البلوتوث • ${device.name ?: device.address}" }
                receiveAudio(s)
            } catch (e: Exception) {
                runOnUiThread { status.text = "تعذر الاتصال: ${e.localizedMessage ?: "تحقق من اقتران الجهازين"}" }
            }
        }
    }

    private fun startTalking() {
        if (recording) return
        if (mode == "internet") {
            status.text = "وضع الإنترنت غير مكتمل بعد: يلزم إعداد خادم WebRTC"
            return
        }
        val s = socket ?: run { status.text = "اتصل بجهاز بلوتوث أولاً"; return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status.text = "اسمح باستخدام الميكروفون"; return
        }
        recording = true
        talkButton.text = "تتحدث الآن… ارفع إصبعك للإيقاف"
        thread {
            try {
                val sampleRate = 16000
                val min = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val recorder = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, sampleRate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096))
                audioRecord = recorder
                recorder.startRecording()
                val buffer = ByteArray(2048)
                val out = BufferedOutputStream(s.outputStream)
                while (recording && socket?.isConnected == true) {
                    val n = recorder.read(buffer, 0, buffer.size)
                    if (n > 0) { out.write((n shr 8) and 0xff); out.write(n and 0xff); out.write(buffer, 0, n); out.flush() }
                }
                recorder.stop(); recorder.release(); audioRecord = null
            } catch (e: Exception) { runOnUiThread { status.text = "انقطع إرسال الصوت: ${e.localizedMessage}" } }
        }
    }

    private fun stopTalking() {
        recording = false
        talkButton.text = "اضغط باستمرار للتحدث"
        try { audioRecord?.stop() } catch (_: Exception) {}
    }

    private fun receiveAudio(s: android.bluetooth.BluetoothSocket) {
        thread {
            try {
                val input = BufferedInputStream(s.inputStream)
                val rate = 16000
                val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                    .setBufferSizeInBytes(maxOf(min, 4096))
                    .setTransferMode(AudioTrack.MODE_STREAM).build()
                audioTrack = track; track.play()
                while (s.isConnected) {
                    val hi = input.read(); if (hi < 0) break
                    val lo = input.read(); if (lo < 0) break
                    val size = (hi shl 8) or lo
                    if (size <= 0 || size > 8192) continue
                    val data = ByteArray(size)
                    var offset = 0
                    while (offset < size) {
                        val n = input.read(data, offset, size - offset)
                        if (n < 0) break
                        offset += n
                    }
                    if (offset == size) track.write(data, 0, size)
                }
                track.stop(); track.release(); audioTrack = null
            } catch (_: Exception) { runOnUiThread { status.text = "انتهى استقبال الصوت أو انقطع الاتصال" } }
        }
    }

    override fun onDestroy() {
        recording = false
        try { socket?.close() } catch (_: Exception) {}
        try { audioTrack?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
