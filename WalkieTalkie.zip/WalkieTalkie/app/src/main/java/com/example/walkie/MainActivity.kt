package com.example.walkie

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.*
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val serviceId = "com.example.walkie.channel"
    private val rate = 16000
    private val myName = "u" + (100000..999999).random()
    private val peers = ConcurrentHashMap.newKeySet<String>()
    private lateinit var client: ConnectionsClient
    private lateinit var status: TextView
    private lateinit var talkBtn: Button
    @Volatile private var talking = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        client = Nearby.getConnectionsClient(this)
        status = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER; text = "جارٍ البحث عن أجهزة قريبة..." }
        talkBtn = Button(this).apply {
            text = "اضغط للتحدث"; textSize = 24f; setBackgroundColor(Color.parseColor("#2E7D32")); setTextColor(Color.WHITE)
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { startTalking(); setBackgroundColor(Color.parseColor("#C62828")); true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { talking = false; setBackgroundColor(Color.parseColor("#2E7D32")); v.performClick(); true }
                    else -> false
                }
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48); layoutDirection = View.LAYOUT_DIRECTION_RTL
            addView(status, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(talkBtn, LinearLayout.LayoutParams(-1, 0, 2f))
        })
        if (missingPermissions().isEmpty()) startNetwork() else requestPermissions(missingPermissions().toTypedArray(), 1)
    }

    private fun neededPermissions(): List<String> {
        val l = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) l += listOf(Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        else l += Manifest.permission.ACCESS_FINE_LOCATION
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.NEARBY_WIFI_DEVICES
        return l
    }
    private fun missingPermissions() = neededPermissions().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (missingPermissions().isEmpty()) startNetwork() else status.text = "الصلاحيات مطلوبة لعمل التطبيق"
    }

    private fun updateStatus() = runOnUiThread {
        status.text = if (peers.isEmpty()) "جارٍ البحث عن أجهزة قريبة..." else "متصل بـ ${peers.size} جهاز"
    }

    // ===== الاتصال: واي فاي أو بلوتوث تلقائياً =====
    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) { client.acceptConnection(id, payloadCb) }
        override fun onConnectionResult(id: String, r: ConnectionResolution) { if (r.status.isSuccess) { peers.add(id); updateStatus() } }
        override fun onDisconnected(id: String) { peers.remove(id); updateStatus() }
    }
    private val discoveryCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            // طرف واحد فقط يبادر بالاتصال لتفادي التعارض
            if (myName < info.endpointName) client.requestConnection(myName, id, lifecycle)
        }
        override fun onEndpointLost(id: String) {}
    }

    private fun startNetwork() {
        val s = Strategy.P2P_CLUSTER
        client.startAdvertising(myName, serviceId, lifecycle, AdvertisingOptions.Builder().setStrategy(s).build())
        client.startDiscovery(serviceId, discoveryCb, DiscoveryOptions.Builder().setStrategy(s).build())
    }

    // ===== استقبال الصوت =====
    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, p: Payload) {
            val input = p.asStream()?.asInputStream() ?: return
            thread {
                val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(min * 2).setTransferMode(AudioTrack.MODE_STREAM).build()
                track.play()
                val buf = ByteArray(min)
                try { while (true) { val n = input.read(buf); if (n < 0) break; track.write(buf, 0, n) } } catch (_: IOException) {}
                finally { track.stop(); track.release(); input.close() }
            }
        }
        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {}
    }

    // ===== إرسال الصوت =====
    private fun startTalking() {
        if (talking || peers.isEmpty()) return
        talking = true
        val pipe = ParcelFileDescriptor.createPipe()
        client.sendPayload(peers.toList(), Payload.fromStream(pipe[0]))
        thread {
            val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
            val out = ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])
            val buf = ByteArray(min)
            rec.startRecording()
            try { while (talking) { val n = rec.read(buf, 0, buf.size); if (n > 0) out.write(buf, 0, n) } } catch (_: IOException) {}
            finally { rec.stop(); rec.release(); out.close() }
        }
    }

    override fun onDestroy() { talking = false; client.stopAllEndpoints(); client.stopAdvertising(); client.stopDiscovery(); super.onDestroy() }
}
